
HOW TO DEPLOY STREAMLIT APP

1. Go to https://share.streamlit.io/deploy
2. Upload this project ZIP
3. Click Deploy
4. App goes LIVE
